# DeleteThing
Automatically fills deletion confirmation fields for Vercel, Netlify, and Cloudflare Pages + Workers.

# Contribution
Feel free to create Issue / make PR for other cloud providers delete page autofill.

# Credits
[Openmoji](https://github.com/hfg-gmuend/openmoji)
 for logo. 

