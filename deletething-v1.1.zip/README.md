<table>
  <tbody>
    <tr>
      <td><img src="./icons/icon48.png" alt="Icon 48" /></td>
      <td><h1>DeleteThing</h1></td>
    </tr>
  </tbody>
</table>

Automatically fills deletion confirmation fields for Vercel, Netlify, and Cloudflare Pages + Workers.

# Usage
## Local: 
Download this repo, visit [chrome://extensions](chrome://extensions) and Enable `Developer Mode` then click `Load Unpacked` and select the repo folder. 
## Remote: 
Download the Extension from Chrome Web Store. 

# Version Histroy
v1.1 - Github deletion added. 
v1.0 - Vercel, Netlify, Cloudflare Pages and Workers. 

# Contribution
Feel free to create Issue / make PR for other cloud providers delete page autofill.

# Credits
[Openmoji](https://github.com/hfg-gmuend/openmoji)
 for logo. 

